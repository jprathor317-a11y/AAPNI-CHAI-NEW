# AAPNI CHAI starter

This is the first UI starter package for the AAPNI CHAI Android app.

Important:
- Login currently demonstrates navigation only; it is NOT real authentication.
- Dashboard tiles are placeholders; Firestore data and billing logic are not connected yet.
- Firebase project configuration (`google-services.json`) must be added before Firebase can be enabled.
- Do not use this starter for live shop accounts until Firebase Authentication, Firestore rules, backups and billing calculations are implemented and tested.

Next step: upload the ZIP to the GitHub repository. Then add the GitHub Actions workflow so GitHub can build the Android APK in the cloud.
