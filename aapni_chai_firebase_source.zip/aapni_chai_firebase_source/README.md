# AAPNI CHAI Firebase-connected starter

Android application ID: `com.aapnichai.admin`.

This version uses Firebase Email/Password Authentication and reads the Firestore `shopkeepers` collection. Dashboard module tiles remain placeholders; full shopkeeper CRUD, tea entries, billing, payments, expenses, reports, security rules and backup must still be implemented and tested before live use.
