import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const AapniChaiApp());
}

class AapniChaiApp extends StatelessWidget {
  const AapniChaiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'AAPNI CHAI', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF8B4513)), useMaterial3: true, scaffoldBackgroundColor: const Color(0xFFFFF9F3)),
    home: const AuthGate(),
  );
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<User?>(
    stream: FirebaseAuth.instance.authStateChanges(),
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) return const Scaffold(body: Center(child: CircularProgressIndicator()));
      return snapshot.data == null ? const LoginPage() : const DashboardPage();
    },
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool loading = false;
  bool obscure = true;
  @override
  void dispose() { email.dispose(); password.dispose(); super.dispose(); }

  Future<void> login() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Email aur password bhariye'))); return;
    }
    setState(() => loading = true);
    try {
      await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      final message = switch (e.code) {
        'user-not-found' => 'Is email ka user nahi mila.',
        'wrong-password' || 'invalid-credential' => 'Email ya password galat hai.',
        'invalid-email' => 'Email sahi format mein likhein.',
        'too-many-requests' => 'Bahut attempts hue. Thodi der baad try karein.',
        _ => e.message ?? 'Login nahi ho paya. Dobara koshish karein.',
      };
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Firebase error: $e')));
    } finally { if (mounted) setState(() => loading = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420), child: Column(children: [
    const CircleAvatar(radius: 48, backgroundColor: Color(0xFF8B4513), child: Icon(Icons.local_cafe, color: Colors.white, size: 48)),
    const SizedBox(height: 16), const Text('AAPNI CHAI', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)), const Text('Admin Management App', style: TextStyle(color: Colors.brown)), const SizedBox(height: 36),
    TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Admin Email ID', prefixIcon: Icon(Icons.email_outlined), border: OutlineInputBorder())),
    const SizedBox(height: 14), TextField(controller: password, obscureText: obscure, decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility : Icons.visibility_off)), border: const OutlineInputBorder()), onSubmitted: (_) { if (!loading) login(); }),
    const SizedBox(height: 20), SizedBox(width: double.infinity, height: 52, child: FilledButton(onPressed: loading ? null : login, child: loading ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('LOGIN'))),
    const SizedBox(height: 12), const Text('Sirf Admin login karega. Shopkeepers ko alag login ki zaroorat nahi.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
  ]))))));
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  static const items = [(Icons.people_alt_outlined, 'Shopkeepers'), (Icons.local_cafe_outlined, 'Tea Entry'), (Icons.receipt_long_outlined, 'Bills'), (Icons.payments_outlined, 'Payments'), (Icons.shopping_bag_outlined, 'Shop Expenses'), (Icons.bar_chart_outlined, 'Reports')];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('AAPNI CHAI'), backgroundColor: const Color(0xFF8B4513), foregroundColor: Colors.white, actions: [IconButton(tooltip: 'Logout', onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout))]),
    body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Dashboard', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: FirebaseFirestore.instance.collection('shopkeepers').snapshots(), builder: (context, snapshot) {
        if (snapshot.hasError) return Text('Shopkeepers read error: ${snapshot.error}', style: const TextStyle(fontSize: 12, color: Colors.red));
        if (!snapshot.hasData) return const Text('Shopkeepers: loading...');
        return Text('Registered Shopkeepers: ${snapshot.data!.docs.length}', style: const TextStyle(color: Colors.brown));
      }), const SizedBox(height: 20),
      Expanded(child: GridView.count(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, children: [for (final item in items) Card(elevation: 1, child: InkWell(borderRadius: BorderRadius.circular(12), onTap: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${item.$2} module agle update mein activate hoga'))), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(item.$1, size: 36, color: const Color(0xFF8B4513)), const SizedBox(height: 10), Text(item.$2, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600))])))])),
    ])),
  );
}
